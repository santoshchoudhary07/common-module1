import { PipeTransform } from '@angular/core';
export declare class SearchPipe implements PipeTransform {
    transform(items: any[], searchItem: string, option: any): any[];
}
