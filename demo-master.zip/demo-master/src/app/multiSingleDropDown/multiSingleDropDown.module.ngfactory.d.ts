import * as i0 from '@angular/core';
import * as i1 from './multiSingleDropDown.module';
export declare const multiSingleDropDownModuleNgFactory: i0.NgModuleFactory<i1.multiSingleDropDownModule>;
