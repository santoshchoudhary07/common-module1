export declare class multiSingleDropDownModule {
}
